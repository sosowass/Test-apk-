plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.mostadiag.app"; compileSdk = 35
 defaultConfig { applicationId = "com.mostadiag.app"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "0.2.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("androidx.core:core:1.15.0") }
