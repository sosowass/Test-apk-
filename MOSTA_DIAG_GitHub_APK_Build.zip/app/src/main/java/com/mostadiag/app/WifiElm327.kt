package com.mostadiag.app

import java.net.InetSocketAddress
import java.net.Socket

/** Wi-Fi ELM327 TCP transport. Connect phone to adapter Wi-Fi before using. */
class WifiElm327 : Elm327() {
    fun connect(host: String = "192.168.0.10", port: Int = 35000) {
        val socket = Socket()
        try {
            socket.connect(InetSocketAddress(host, port), 5000)
            attach(socket.getInputStream(), socket.getOutputStream()) { socket.close() }
            initialize()
        } catch (e: Exception) { try { socket.close() } catch (_: Exception) {}; throw e }
    }
}
