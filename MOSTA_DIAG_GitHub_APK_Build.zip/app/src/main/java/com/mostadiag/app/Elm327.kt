package com.mostadiag.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Standard ELM327 command transport; call from a single background executor. */
open class Elm327 {
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var closer: (() -> Unit)? = null
    protected fun attach(i: InputStream, o: OutputStream, close: () -> Unit) {
        this.input = i; this.output = o; this.closer = close
    }
    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        close()
        val s = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        try { s.connect(); attach(s.inputStream, s.outputStream) { s.close() }; initialize() }
        catch (e: Exception) { try { s.close() } catch (_: Exception) {}; throw e }
    }
    protected fun initialize() {
        listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0").forEach { command(it, 5500) }
    }
    @Synchronized fun command(cmd: String, timeoutMs: Long = 3500): String {
        val out = output ?: error("Boîtier non connecté")
        val stream = input ?: error("Flux absent")
        while (stream.available() > 0) stream.read()
        out.write((cmd + "\r").toByteArray(Charsets.US_ASCII)); out.flush()
        val deadline = System.currentTimeMillis() + timeoutMs
        val data = StringBuilder()
        while (System.currentTimeMillis() < deadline) {
            if (Thread.currentThread().isInterrupted) error("Lecture interrompue")
            if (stream.available() > 0) {
                val b = stream.read()
                if (b < 0) error("Connexion fermée")
                if (b == '>'.code) {
                    val response = data.toString().trim()
                    if (response.contains("NO DATA", true) || response.contains("UNABLE TO CONNECT", true) || response.contains("ERROR", true)) error(response)
                    return response
                }
                data.append(b.toChar())
            } else Thread.sleep(25)
        }
        error("Délai dépassé ($cmd)")
    }
    fun pid(pid: String): List<Int> {
        val response = command("01$pid").uppercase().replace("\r", "\n")
        val hex = response.replace(Regex("[^0-9A-F]"), "")
        val marker = "41$pid"
        val start = hex.indexOf(marker)
        if (start < 0) error("PID $pid indisponible")
        return hex.substring(start + marker.length).chunked(2).filter { it.length == 2 }.map { it.toInt(16) }
    }
    fun dtcs(): List<String> {
        val hex = command("03", 6500).uppercase().replace(Regex("[^0-9A-F]"), "")
        val start = hex.indexOf("43")
        if (start < 0) return emptyList()
        val bytes = hex.substring(start + 2).chunked(2).filter { it.length == 2 }.map { it.toInt(16) }
        return bytes.chunked(2).filter { it.size == 2 && (it[0] != 0 || it[1] != 0) }.map {
            val a = it[0]; val b = it[1]
            "${"PCBU"[a shr 6]}${(a shr 4) and 3}${(a and 15).toString(16).uppercase()}${(b shr 4).toString(16).uppercase()}${(b and 15).toString(16).uppercase()}"
        }
    }
    fun vin(): String {
        val hex = command("0902", 7000).uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = "4902"
        val pos = hex.indexOf(marker)
        if (pos < 0) return "VIN indisponible : $hex"
        return hex.substring(pos + 6).chunked(2).mapNotNull { it.toIntOrNull(16)?.toChar() }.filter { it.code in 32..126 }.joinToString("")
    }
    fun clearCodes() { command("04", 6500) }
    @Synchronized fun close() { try { closer?.invoke() } catch (_: Exception) {}; closer = null; input = null; output = null }
}
