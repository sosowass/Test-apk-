package com.mostadiag.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.content.Intent
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import androidx.core.content.FileProvider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private var elm: Elm327 = Elm327()
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private var connected = false
    private var currentPage = "Accueil"
    private val history = mutableListOf<String>()
    private fun record(item: String) {
        val line = "${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.FRANCE).format(Date())}  $item"
        history.add(0, line)
        getSharedPreferences("mosta_history", MODE_PRIVATE).edit().putString("lines", history.take(100).joinToString("\n")).apply()
    }
    private val bg = Color.rgb(6, 16, 30)
    private val blue = Color.rgb(21, 166, 255)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); history.addAll(getSharedPreferences("mosta_history", MODE_PRIVATE).getString("lines", "")!!.lines().filter { it.isNotBlank() }); showPage("Accueil") }
    private fun label(text: String, size: Float = 17f, color: Int = Color.WHITE): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(14, 16, 14, 16)
    }
    private fun button(text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(blue); cornerRadius = 22f }
            setOnClickListener { action() } }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(12, 8, 12, 8) })
    }
    private fun info(text: String) { root.addView(label(text, 16f, Color.rgb(183, 206, 225))) }
    private fun showPage(page: String) {
        currentPage = page
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = label("◈ MOSTA DIAG  /  $page", 23f, blue).apply { setTypeface(null, Typeface.BOLD) }
        outer.addView(header)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 10, 16, 20) }
        scroll.addView(root); outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Accueil", "Connexion", "Mesures", "Défauts", "Historique").forEach { dest ->
            nav.addView(TextView(this).apply { text = dest; textSize = 12f; gravity = 17; setTextColor(if (dest == page) blue else Color.WHITE)
                setPadding(2, 20, 2, 20); setOnClickListener { showPage(dest) } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(nav); setContentView(outer)
        when(page) {
            "Accueil" -> { info("Diagnostic automobile OBD2 · Bluetooth Classic ELM327")
                info(if (connected) "● Boîtier connecté" else "○ Aucun boîtier connecté")
                button("Connecter mon boîtier") { showPage("Connexion") }
                button("Lire les mesures") { showPage("Mesures") }
                button("Lire les défauts") { showPage("Défauts") }
                button("Informations véhicule") { showPage("Véhicule") }
            }
            "Connexion" -> { info("Associez d'abord votre adaptateur ELM327 dans les réglages Bluetooth Android, puis choisissez-le ci-dessous.")
                button("Choisir un appareil Bluetooth associé") { chooseDevice() }
                button("Connexion Wi-Fi ELM327 (192.168.0.10:35000)") { connectWifi() }
                if (connected) button("Déconnecter") { elm.close(); connected = false; showPage("Connexion") }
            }
            "Mesures" -> { info("Valeurs réelles lues sur le calculateur moteur (si PID pris en charge).")
                button("Actualiser les mesures") { perform("Lecture des mesures") {
                    val rpm = elm.pid("0C"); val speed = elm.pid("0D"); val coolant = elm.pid("05")
                    val rpmValue = ((rpm[0] * 256 + rpm[1]) / 4.0)
                    "Régime : $rpmValue tr/min\nVitesse : ${speed[0]} km/h\nLiquide refroidissement : ${coolant[0] - 40} °C".also { record("Mesures : " + it.replace("\n", " / ")) }
                } }
            }
            "Défauts" -> { info("Lecture des DTC OBD2 moteur. L'effacement peut réinitialiser les moniteurs antipollution.")
                button("Lire les codes défauts") { perform("Lecture DTC") {
                    val codes = elm.dtcs(); record("Lecture : ${codes.joinToString().ifEmpty { "aucun code" }}")
                    codes.joinToString("\n").ifEmpty { "Aucun code défaut signalé" }
                } }
                button("Effacer les codes défauts") { AlertDialog.Builder(this)
                    .setTitle("Confirmer l'effacement")
                    .setMessage("Cette action efface les codes moteur et peut réinitialiser les moniteurs OBD. Ne l'effectuez qu'après diagnostic et réparation. Continuer ?")
                    .setNegativeButton("Annuler", null).setPositiveButton("Effacer") { _, _ -> perform("Effacement") {
                        elm.clearCodes(); record("Demande d'effacement envoyée"); "Commande d'effacement envoyée. Relisez les codes pour vérifier."
                    } }.show() }
            }
            "Historique" -> { info("Historique de cette session (non conservé après fermeture).")
                history.forEach { info(it) }
                button("Exporter mon historique en PDF") { exportPdf() } }
            "Véhicule" -> { info("Informations disponibles via OBD2 standard : VIN (mode 09) et identifiants calculateur selon compatibilité.")
                button("Lire la réponse VIN brute") { perform("Lecture VIN") { elm.vin() } }
            }
        }
    }
    private fun perform(title: String, action: () -> String) {
        if (!connected) { Toast.makeText(this, "Connectez d'abord un boîtier", Toast.LENGTH_LONG).show(); return }
        val output = label("$title en cours…", 16f, blue); root.addView(output)
        worker.execute { val result = try { action() } catch (e: Exception) { "Erreur : ${e.message}" }
            runOnUiThread { output.text = result } }
    }
    @SuppressLint("MissingPermission")
    private fun chooseDevice() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 100); return
        }
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { info("Activez le Bluetooth dans les réglages Android."); return }
        val devices = adapter.bondedDevices.toList()
        if (devices.isEmpty()) { info("Aucun appareil associé. Associez votre ELM327 dans les réglages Bluetooth."); return }
        AlertDialog.Builder(this).setTitle("Choisir le boîtier")
            .setItems(devices.map { "${it.name ?: "Sans nom"} (${it.address})" }.toTypedArray()) { _, index ->
                val status = label("Connexion en cours…", 16f, blue); root.addView(status)
                worker.execute { val result = try { elm.connect(devices[index]); connected = true; "Connexion OBD2 établie" }
                    catch (e: Exception) { connected = false; "Connexion impossible : ${e.message}" }
                    runOnUiThread { status.text = result } }
            }.show()
    }
    private fun connectWifi() {
        val status = label("Connexion Wi-Fi en cours…", 16f, blue); root.addView(status)
        worker.execute {
            val result = try {
                elm.close(); val wifi = WifiElm327(); wifi.connect(); elm = wifi; connected = true
                record("Connexion Wi-Fi OBD2 établie"); "Connexion Wi-Fi OBD2 établie"
            } catch (e: Exception) { connected = false; "Échec Wi-Fi : ${e.message}. Vérifiez le réseau et l'adresse du boîtier." }
            runOnUiThread { status.text = result }
        }
    }
    private fun exportPdf() {
        try {
            val pdf = PdfDocument()
            val paint = android.graphics.Paint().apply { isAntiAlias = true; textSize = 12f; color = android.graphics.Color.BLACK }
            val lines = listOf("MOSTA DIAG — Historique de diagnostics", "Date : ${Date()}", "") + history
            var index = 0; var pageNumber = 1
            while (index < lines.size) {
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create())
                var y = 48f
                while (index < lines.size && y < 800f) {
                    val line = lines[index++].take(85)
                    page.canvas.drawText(line, 35f, y, paint); y += 19f
                }
                pdf.finishPage(page)
            }
            val file = File(cacheDir, "mosta_diag_historique.pdf")
            FileOutputStream(file).use { pdf.writeTo(it) }; pdf.close()
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(intent, "Partager le rapport MOSTA DIAG"))
        } catch (e: Exception) { Toast.makeText(this, "Export PDF impossible : ${e.message}", Toast.LENGTH_LONG).show() }
    }
    override fun onDestroy() { elm.close(); worker.shutdownNow(); super.onDestroy() }
}
