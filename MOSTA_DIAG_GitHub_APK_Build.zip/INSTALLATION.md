# Installer MOSTA DIAG

Ce dépôt contient le code source Android, **pas encore un APK validé**.

1. Créer un dépôt GitHub vide, puis importer le contenu du dossier `mosta-diag` à sa racine (pas le dossier parent).
2. Ouvrir **Actions** > **Construire MOSTA DIAG APK** > **Run workflow**.
3. Attendre la fin de la compilation. Si le workflow échoue, consulter les logs : aucun APK n'aura été généré.
4. Si le workflow réussit, ouvrir son exécution puis télécharger l'artifact `MOSTA-DIAG-APK`.
5. Décompresser le ZIP téléchargé, transférer `app-debug.apk` sur Android, l'ouvrir et autoriser l'installation depuis cette source.

ATTENTION : il s'agit d'une version de développement non testée sur véhicule réel. Ne jamais effacer les codes défauts sans avoir identifié la cause.
