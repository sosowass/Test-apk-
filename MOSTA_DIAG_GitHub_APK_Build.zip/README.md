# MOSTA DIAG — Android OBD2

Projet Android Kotlin indépendant, avec identité MOSTA DIAG. Ce n'est pas une modification de l'APK propriétaire fourni.

## Ouvrir et compiler
1. Installer Android Studio (JDK 17 et Android SDK 35).
2. Ouvrir ce dossier comme projet Gradle et synchroniser.
3. Choisir un appareil Android physique, puis **Run** ou **Build > Build APK(s)**.
4. Associer préalablement un adaptateur **ELM327 Bluetooth Classic SPP** dans les réglages Android.
5. Dans MOSTA DIAG : Connexion > choisir l'appareil associé.

## Implémenté
- Connexion Bluetooth Classic RFCOMM/SPP, initialisation ELM327 ATZ/ATE0/ATL0/ATS0/ATH0/ATSP0.
- PIDs mode 01 : régime (010C), vitesse (010D), température liquide (0105).
- Lecture des codes défauts mode 03, commande d'effacement mode 04 avec confirmation.
- Lecture de la réponse brute VIN mode 09 PID 02.
- Historique temporaire en mémoire, interface Android native française et icône vectorielle MOSTA DIAG.

## Limitations importantes
- **Non compilé ni testé sur boîtier réel dans cet environnement.** Aucun APK installable n'est inclus.
- Uniquement adaptateurs Bluetooth Classic SPP, pas BLE ni Wi-Fi pour cette première base.
- Parseur ELM327 de base : les réponses CAN multi-trames, entêtes, échos imprévus et les adaptateurs clones peuvent demander un parseur plus robuste.
- L'effacement des codes ne garantit pas la réparation. Ne pas manipuler en conduisant.
- Certains véhicules et calculateurs ne supportent pas tous les PIDs. Pas de diagnostic ABS/airbag constructeur.
- Historique non persistant, rapports PDF et graphiques non encore développés.
- Les autorisations Bluetooth sont demandées à l'utilisation. Si la permission est accordée, retoucher le bouton pour ouvrir la liste.

## Prochaine étape
Tester avec un véritable adaptateur et un véhicule, fiabiliser le protocole, ajouter tests, stockage, rapports et design final.
